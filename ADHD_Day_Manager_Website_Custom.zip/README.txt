ADHD Day Manager (HTML)

This folder contains a mobile-friendly HTML page Gavin can open on any phone.

FILES
- index.html  -> The webpage (open this)

HOW TO SHARE (Google Drive)
1) Upload index.html to Google Drive.
2) Right-click -> Get link -> Change to "Anyone with the link" -> Copy link.
3) Share the link with Gavin. He may need to tap "Open in" and choose a browser if Drive previews it as text.

HOW TO PUBLISH (GitHub Pages)
1) Create a new public repo named: take-a-minute
2) Upload index.html to the repo root.
3) In repo Settings -> Pages -> Source: "Deploy from a branch", Branch: "main", Folder: "/ (root)". Save.
4) After a minute, your site will be live at:
   https://markyjm-eng.github.io/take-a-minute

OPTIONAL
- You can rename the site/repo however you like, but this link will change if you do.
