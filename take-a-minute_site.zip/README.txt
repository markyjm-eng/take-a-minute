ADHD Day Manager (Embedded Wind-Down Scripts)

This folder contains a mobile-friendly HTML page Gavin can open on any phone.

FILES
- index.html  -> The webpage (open this)

HOW TO PUBLISH (GitHub Pages)
1) Create (or open) public repo named: take-a-minute
2) Upload index.html to the repo root.
3) In repo Settings -> Pages -> Source: "Deploy from a branch", Branch: "main", Folder: "/ (root)". Save.
4) Your site will be live at:
   https://markyjm-eng.github.io/take-a-minute

UPDATING
- To update the page later, upload a new index.html and Commit changes.
